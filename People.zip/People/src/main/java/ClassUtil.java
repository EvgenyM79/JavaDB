import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

public class ClassUtil {

    public void startProject() throws SQLException {
        ObjectDAO obj = new ObjectDAO();
        Parents parent1 = new Parents("Иван","Петров",49);
        Passport passport1 = new Passport("6403",333234543,"Куйбышева", 57, 7);
        Parents parent2 = new Parents("Вера","Петровна",47);
        Passport passport2 = new Passport("6503",333234443,"Куйбышева", 57, 7);
        Parents parent3 = new Parents("Николай","Сергеевич",43);
        Passport passport3 = new Passport("6573",333124543,"Гоголя", 44, 9);
        Parents parent4 = new Parents("Анна","Сергеевна",43);
        Passport passport4 = new Passport("6023",333124234,"Гоголя", 44, 9);
        obj.save(parent1);
        obj.save(passport1);
        obj.save(parent2);
        obj.save(passport2);
        obj.save(parent3);
        obj.save(passport3);
        obj.save(parent4);
        obj.save(passport4);
        Children child1 = new Children("Миша","Петров",12);
        child1.getParents().add(parent1);
        child1.getParents().add(parent2);
        obj.save(child1);
        EducateBuilding educateBuilding1 = new EducateBuilding("Новая школа","Северная",7);
        obj.save(educateBuilding1);
        //educateBuilding1.getChildren().add(child1);
        AreaStreet areaStreet1 = new AreaStreet("Первомайская", "Северная");
        obj.save(areaStreet1);

        Children child2 = new Children("Юлия","Сергеевна",9);
        child2.getParents().add(parent2);
        obj.save(child2);




        Parents p = obj.findById(1);
        System.out.println("{" + p.getId() + "}{" + p.getFirstName() + "}{" + p.getLastName() + "}{"  + p.getAge() + "}");
        String nameObject = "Parents";
        String nameValue = "lastName";
        //List<Parents> list2 = obj.getObjFromTable(nameObject,nameValue, Arrays.<Object>asList(new Integer[] { 24, 27}));
        List<Parents> list2 = obj.getObjFromTable(nameObject,nameValue, Arrays.<Object>asList(new String[] { "Петров", "Петровна"}));
        System.out.println(list2);

        String objParents = "Parents";
        List<Parents> list = obj.getObjFromTable(objParents);
        System.out.println(list);
        for (Parents pAll: list){
            System.out.println("{" + pAll.getId() + "}{" + pAll.getFirstName() + "}{" + pAll.getLastName() + "}{"  + pAll.getAge() + "}");
        }
        List<ObjectDAO> list3 = obj.getObjFromTable("Parents", "");
        //obj.getObjFromTable();
        //System.out.println(list3.get(1));
        //System.out.println((Children)list3);
    }
}
