import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "areastreet")
public class AreaStreet {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idAS;

    @Column(name = "asStreet")
    private String asStreet;

    @Column(name = "asArea")
    private String asArea;

    /*@OneToMany(cascade = {CascadeType.PERSIST} )
    @JoinTable(name = "ebuilding",
            joinColumns = { @JoinColumn(name = "eb_street") })*/

    //private Set<Children> children = new HashSet<Children>();
    //private List<EducateBuilding> educateBuildings = new ArrayList<EducateBuilding>();

    public AreaStreet(String asStreet, String asArea) {
        this.asStreet = asStreet;
        this.asArea = asArea;
    }

    public int getIdAS() {
        return idAS;
    }

    public void setIdAS(int idAS) {
        this.idAS = idAS;
    }

    public String getAsStreet() {
        return asStreet;
    }

    public void setAsStreet(String asStreet) {
        this.asStreet = asStreet;
    }

    public String getAsArea() {
        return asArea;
    }

    public void setAsArea(String asArea) {
        this.asArea = asArea;
    }

    /*public List<EducateBuilding> getEducateBuildings() {
        return educateBuildings;
    }

    public void setEducateBuildings(List<EducateBuilding> educateBuildings) {
        this.educateBuildings = educateBuildings;
    }*/

    @Override
    public String toString(){
        return "{" + idAS + "} {" + asStreet + "} {" + asArea + "}\n";
    }
}
