import org.dom4j.tree.AbstractEntity;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "parents")

public class Parents{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idParent;

    @Column(name = "firstName")
    private String firstName;

    @Column(name = "lastName")
    private String lastName;

    @Column(name = "age")
    private int age;

    @ManyToMany(cascade = { CascadeType.ALL})
    @JoinTable(name = "parents_has_children",
            joinColumns = { @JoinColumn(name = "idParent") },
            inverseJoinColumns = { @JoinColumn(name = "idChild") })

    private Set<Children> children = new HashSet<Children>();
    //private List<Children> children = new ArrayList<Children>();

    public Parents(String firstName, String lastName, Integer age) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
    }

    public Parents(){};

    public int getId() {
        return idParent;
    }

    public void setId(int id) {
        this.idParent = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastname) {
        this.lastName = lastName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Set<Children> getChild() {
    //public List<Children> getChildren() {
        return children;
    }
    public void setChild(Set<Children> children ) {
    //public void setChild(List<Children> children ) {
        this.children = children;
    }

    @Override
    public String toString(){
        return "{" + idParent + "} {" + firstName + "} {" + lastName + "} {" + age + "}\n";
    }
}