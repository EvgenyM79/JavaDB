import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "ebuilding")
public class EducateBuilding {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idEB;

    @Column(name = "ebName")
    private String ebName;

    @Column(name = "ebStreet")
    private String ebStreet;

    @Column(name = "ebN")
    private int ebN;

    /*@OneToMany(cascade = {CascadeType.PERSIST} )
    @JoinTable(name = "children",
            joinColumns = { @JoinColumn(name = "idEB") })
    //private Set<Children> children = new HashSet<Children>();
    private List<Children> children = new ArrayList<Children>();*/

    public EducateBuilding(String ebName, String ebStreet, int ebN) {
        this.ebName = ebName;
        this.ebStreet = ebStreet;
        this.ebN = ebN;
    }

    public int getIdEB() {
        return idEB;
    }

    public void setIdEB(int idEB) {
        this.idEB = idEB;
    }

    public String getEbName() {
        return ebName;
    }

    public void setEbName(String ebName) {
        this.ebName = ebName;
    }

    public String getEbStreet() {
        return ebStreet;
    }

    public void setEbStreet(String ebStreet) {
        this.ebStreet = ebStreet;
    }

    public int getEbN() {
        return ebN;
    }

    public void setEbN(int ebN) {
        this.ebN = ebN;
    }

    /*public List<Children> getChildren() {
        return children;
    }

    public void setChildren(List<Children> children) {
        this.children = children;
    }*/

    @Override
    public String toString(){
        return "{" + idEB + "} {" + ebName + "} {" + ebStreet + "} {" + ebN + "}\n";
    }

}
