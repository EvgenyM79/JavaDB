import org.dom4j.tree.AbstractEntity;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "children")

public class Children{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idChild;

    @Column(name = "firstName")
    private String firstName;

    @Column(name = "lastName")
    private String lastName;

    @Column(name = "age")
    private int age;

    @ManyToMany(cascade = { CascadeType.PERSIST })
    @JoinTable(name = "parents_has_children",
            joinColumns = { @JoinColumn(name = "idChild") },
            inverseJoinColumns = { @JoinColumn(name = "idParent") })
    //private List<Parents> parents = new ArrayList<Parents>();
    private Set<Parents> parents = new HashSet<Parents>();

    public Children(String firstName, String lastName, Integer age) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
    }


    public Children(){};

    public int getId() {
        return idChild;
    }

    public void setId(int id) {
        this.idChild = id;
    }

    public String getfirstName() {
        return firstName;
    }

    public void setName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastname) {
        this.lastName = lastName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Set<Parents> getParents() {
    //public List<Parents> getParents() {
        return parents;
    }

    @Override
    public String toString(){
        return "{" + idChild + "} {" + firstName + "} {" + lastName + "} {" + age + "}\n";
    }

    public void setParents(Set<Parents> parents) {
    //public void setParents(List<Parents> parents) {
        this.parents = parents;
    }
}