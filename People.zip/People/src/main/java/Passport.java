//import org.hibernate.annotations.Table;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "passport")
public class Passport{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idPassportd;

    @Column(name = "serPassport")
    private String serPassport;

    @Column(name = "nPassport")
    private Integer nPassport;

    @Column(name = "nStreet")
    private String nStreet;

    @Column(name = "nBuilding")
    private int nBuilding;

    @Column(name = "nRoom")
    private int nRoom;


    /*@OneToOne(cascade = {CascadeType.ALL})
    @JoinTable(name = "parents",
            joinColumns = { @JoinColumn(name = "passport_id") })
    //private Set<Children> children = new HashSet<Children>();
    private Parents parent;*/

    public Passport(String serPassport, int nPassport, String nStreet, int nBuilding, int nRoom) {
        this.serPassport = serPassport;
        this.nPassport = nPassport;
        this.nStreet = nStreet;
        this.nBuilding = nBuilding;
        this.nRoom = nRoom;
    }

    public Passport(){};

    public int getIdPassportd() {
        return idPassportd;
    }

    public void setIdPassportd(int idPassportd) {
        this.idPassportd = idPassportd;
    }

    public String getSerPassport() {
        return serPassport;
    }

    public void setSerPassport(String serPassport) {
        this.serPassport = serPassport;
    }

    public Integer getNPassport() {
        return nPassport;
    }

    public void setNPassport(Integer nPassport) {
        this.nPassport = nPassport;
    }

    public String getnStreet() {
        return nStreet;
    }

    public void setnStreet(String nStreet) {
        this.nStreet = nStreet;
    }

    public int getnBuilding() {
        return nBuilding;
    }

    public void setnBuilding(int nBuilding) {
        this.nBuilding = nBuilding;
    }

    public int getNRoom() {
        return nRoom;
    }

    public void setNRoom(int nRoom) {
        this.nRoom = nRoom;
    }

    /*public Parents getParent() {
        return parent;
    }

    public void setParent(Parents parent) {
        this.parent = parent;
    }*/

    @Override
    public String toString(){
        return "{" + idPassportd + "} {" + serPassport + "} {" + nPassport + "} {" + nStreet + "}{" + nBuilding + "}{" + nRoom + "}\n";
    }




}