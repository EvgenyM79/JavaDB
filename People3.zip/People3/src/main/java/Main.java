import java.util.Arrays;
import java.util.List;
import java.sql.SQLException;

public class Main {
    public static void main(String[] args) throws Exception {
        ClassUtil classUtil = new ClassUtil();
        classUtil.startProject();
    }

}
