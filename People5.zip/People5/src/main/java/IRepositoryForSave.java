import java.io.IOException;

public interface IRepositoryForSave<T> {
/*    public interface object <T> objSave(Object obj) throws IOException;
    public interface IFileRW {
        //List<String> readFile(String filename) throws IOException;
        //String writeFile(String fileName, String strCar) throws IOException;*/
}
