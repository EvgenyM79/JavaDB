import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

public class ClassUtil {

    public void startProject() throws SQLException {
        ObjectDAO obj = new ObjectDAO();
        Parents parent1 = new Parents("Иван","Петров",49);
        Passport passport1 = new Passport("6403",333234543,"Куйбышева", 57, 7);
        AreaStreet areaStreet1 = new AreaStreet("Куйбышева", "Октябрьский");
        Children child1 = new Children("Миша","Петров",12);

        obj.save(areaStreet1);
        passport1.setAreaStreet(areaStreet1);
        obj.save(passport1);
        parent1.setPassport(passport1);
        obj.save(parent1);
        child1.getParents().add(parent1);
        obj.save(child1);

        Parents parent2 = new Parents("Вера","Петровна",47);
        Passport passport2 = new Passport("6503",333234443,"Куйбышева", 57, 7);
        obj.save(areaStreet1);
        passport2.setAreaStreet(areaStreet1);
        obj.save(passport2);
        parent2.setPassport(passport2);
        child1.getParents().add(parent2);
        obj.save(parent2);


        Parents parent3 = new Parents("Николай","Сергеевич",43);
        Passport passport3 = new Passport("6573",333124543,"Гоголя", 44, 9);
        AreaStreet areaStreet3 = new AreaStreet("Гоголя", "Октябрьский");
        obj.save(areaStreet3);
        passport3.setAreaStreet(areaStreet3);
        obj.save(passport3);
        parent3.setPassport(passport3);
        obj.save(parent3);



        EducateBuilding educateBuilding1 = new EducateBuilding("Новая школа","Первомайская",7);
        obj.save(educateBuilding1);
        //educateBuilding1.getChildren().add(child1);

        Children child2 = new Children("Юлия","Сергеевна",9);
        child2.getParents().add(parent2);
        obj.save(child2);




        /*Parents p = obj.findById(1);
        System.out.println("{" + p.getId() + "}{" + p.getFirst_name() + "}{" + p.getLastName() + "}{"  + p.getAge() + "}");
        String nameObject = "Parents";
        String nameValue = "last_name";
        //List<Parents> list2 = obj.getObjFromTable(nameObject,nameValue, Arrays.<Object>asList(new Integer[] { 24, 27}));
        List<Parents> list2 = obj.getObjFromTable(nameObject,nameValue, Arrays.<Object>asList(new String[] { "Петров", "Петровна"}));
        System.out.println(list2);

        String objParents = "Parents";
        List<Parents> list = obj.getObjFromTable(objParents);
        System.out.println(list);
        for (Parents pAll: list){
            System.out.println("{" + pAll.getId() + "}{" + pAll.getFirst_name() + "}{" + pAll.getLastName() + "}{"  + pAll.getAge() + "}");
        }
        List<ObjectDAO> list3 = obj.getObjFromTable("Parents", "");
        //obj.getObjFromTable();
        //System.out.println(list3.get(1));
        //System.out.println((Children)list3);*/
    }
}
