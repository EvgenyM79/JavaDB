//import org.hibernate.annotations.Entity;
//import org.hibernate.annotations.Table;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "User")

public class User implements Serializable {

        @Id
        @Column(name = "id")
        @GeneratedValue

        private int id;
        private String name;

    public int getId() {
        return id;
    }

    public void setId(int id1){
        id = id1;
    }

    public String getName(){
        return name;
    }

    public void setName(String name1){
        name = name1;
    }

        //@OneToOne
        //@MapsId
        //@JoinColumn(name = "passport")
        //private Passport pasport;


}


