import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "ebuilding")
public class EducateBuilding {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int eb_id;

    @Column(name = "eb_name")
    private String eb_name;

    @Column(name = "eb_street")
    private String eb_street;

    @Column(name = "eb_n")
    private int eb_n;

    /*@OneToMany(cascade = {CascadeType.PERSIST} )
    @JoinTable(name = "children",
            joinColumns = { @JoinColumn(name = "eb_id") })
    //private Set<Children> children = new HashSet<Children>();
    private List<Children> children = new ArrayList<Children>();*/

    public EducateBuilding(String eb_name, String eb_street, int eb_n) {
        this.eb_name = eb_name;
        this.eb_street = eb_street;
        this.eb_n = eb_n;
    }

    public int getEb_id() {
        return eb_id;
    }

    public void setEb_id(int eb_id) {
        this.eb_id = eb_id;
    }

    public String getEb_name() {
        return eb_name;
    }

    public void setEb_name(String eb_name) {
        this.eb_name = eb_name;
    }

    public String getEb_street() {
        return eb_street;
    }

    public void setEb_street(String eb_street) {
        this.eb_street = eb_street;
    }

    public int getEb_n() {
        return eb_n;
    }

    public void setEb_n(int eb_n) {
        this.eb_n = eb_n;
    }

    /*public List<Children> getChildren() {
        return children;
    }

    public void setChildren(List<Children> children) {
        this.children = children;
    }*/

    @Override
    public String toString(){
        return "{" + eb_id + "} {" + eb_name + "} {" + eb_street + "} {" + eb_n + "}\n";
    }

}
