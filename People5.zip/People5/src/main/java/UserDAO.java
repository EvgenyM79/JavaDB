import org.hibernate.Session;
import org.hibernate.Transaction;

public class UserDAO{


    public void save(Object obj) {
        Session session = HibernateUtils.getSessionFactory().openSession();
        Transaction tx1 = session.beginTransaction();
        session.save(obj);
        tx1.commit();
        session.close();
    }

    /*public void save(Children children) {
        Session session = HibernateUtils.getSessionFactory().openSession();
        Transaction tx1 = session.beginTransaction();
        session.save(children);
        tx1.commit();
        session.close();
    }*/

    public User findById(int id) {
        return HibernateUtils.getSessionFactory().openSession().get(User.class, id);
    }

}

