import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "parents_has_children")

public class ChildrenParents {
    private Integer parant_id, child_id;

    public ChildrenParents(Integer parant_id, Integer child_id){
        this.parant_id = parant_id;
        this.child_id = child_id;
    }

    public Integer getChild_id() {
        return child_id;
    }

    public Integer getParant_id() {
        return parant_id;
    }
}
