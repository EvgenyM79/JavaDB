import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "areastreet")
public class AreaStreet {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int as_id;

    @Column(name = "as_street")
    private String as_street;

    @Column(name = "as_area")
    private String as_area;


    @OneToMany(cascade = {CascadeType.PERSIST} )
    @JoinColumn(name = "as_street")
    private List<Passport> passports;

    //private Set<Children> children = new HashSet<Children>();
    //private List<EducateBuilding> educateBuildings = new ArrayList<EducateBuilding>();

    public AreaStreet(String as_street, String as_area) {
        this.as_street = as_street;
        this.as_area = as_area;
    }

    public int getAs_id() {
        return as_id;
    }

    public void setAs_id(int as_id) {
        this.as_id = as_id;
    }

    public String getAs_street() {
        return as_street;
    }

    public void setAs_street(String as_street) {
        this.as_street = as_street;
    }

    public String getAs_area() {
        return as_area;
    }

    public void setAs_area(String as_area) {
        this.as_area = as_area;
    }

    public List<Passport> getPassports() {
        return passports;
    }

    public void setPassports(List<Passport> passports) {
        this.passports = passports;
    }

    /*public List<EducateBuilding> getEducateBuildings() {
        return educateBuildings;
    }

    public void setEducateBuildings(List<EducateBuilding> educateBuildings) {
        this.educateBuildings = educateBuildings;
    }*/

    @Override
    public String toString(){
        return "{" + as_id + "} {" + as_street + "} {" + as_area + "}\n";
    }
}
